const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const tmdbApiKey = process.env.TMDB_API_KEY;
const youTubeApiKey = process.env.YOUTUBE_API_KEY;

app.get('/api/movies/popular', async (req, res) => {
    try {
        const response = await axios.get(`https://api.themoviedb.org/3/movie/popular?api_key=${tmdbApiKey}`);
        res.json(response.data.results);
    } catch (error) {
        console.error('Error fetching popular movies:', error.response ? error.response.data : error.message);
        res.status(500).json({ error: 'Failed to fetch popular movies' });
    }
});

app.get('/api/movies/search', async (req, res) => {
    const query = req.query.query;
    try {
        const response = await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${tmdbApiKey}&query=${query}`);
        res.json(response.data.results);
    } catch (error) {
        console.error('Error searching movies:', error.response ? error.response.data : error.message);
        res.status(500).json({ error: 'Failed to search movies' });
    }
});

app.get('/api/movies/:id', async (req, res) => {
    const movieId = req.params.id;
    try {
        console.log(`Fetching details for movie ID: ${movieId}`);

        const movieResponse = await axios.get(`https://api.themoviedb.org/3/movie/${movieId}?api_key=${tmdbApiKey}&append_to_response=credits`);
        const movieTitle = movieResponse.data.title.toLowerCase();
        const movieDuration = movieResponse.data.runtime; // Duration in minutes

        // YouTube search for the full movie
        const youtubeResponse = await axios.get(`https://www.googleapis.com/youtube/v3/search`, {
            params: {
                part: 'snippet',
                q: `${movieResponse.data.title} full movie`,
                type: 'video',
                key: youTubeApiKey,
                maxResults: 10,
            }
        });

        // Fetch video details for duration check
        const videoIds = youtubeResponse.data.items.map(item => item.id.videoId).join(',');
        const videoDetailsResponse = await axios.get(`https://www.googleapis.com/youtube/v3/videos`, {
            params: {
                part: 'contentDetails,snippet',
                id: videoIds,
                key: youTubeApiKey,
            }
        });

        console.log(`YouTube search results for "${movieResponse.data.title}":`, videoDetailsResponse.data.items);

        // Select the most relevant video based on strict metadata
        let youtubeVideoId = null;
        const filteredVideos = videoDetailsResponse.data.items.filter(video => {
            const titleMatch = video.snippet.title.toLowerCase().includes(movieTitle);
            const durationMatch = parseDuration(video.contentDetails.duration) >= 60; // At least 1 hour
            const isNotTrailer = !video.snippet.title.toLowerCase().includes("trailer") && !video.snippet.description.toLowerCase().includes("trailer");
            console.log(`Checking video "${video.snippet.title}" with duration ${parseDuration(video.contentDetails.duration)} minutes. Title match: ${titleMatch}, Duration match: ${durationMatch}, Not a trailer: ${isNotTrailer}`);
            return titleMatch && durationMatch && isNotTrailer;
        });

        if (filteredVideos.length > 0) {
            youtubeVideoId = filteredVideos[0].id;
        } else {
            console.warn('No videos found with strict criteria.');
            return res.status(404).json({ error: 'Sorry, couldn\'t get the movie.' });
        }

        res.json({ movie: movieResponse.data, trailer: trailerResponse.data.items[0], youtubeVideoId });
    } catch (error) {
        console.error('Error fetching movie details:', error.response ? error.response.data : error.message);
        res.status(error.response ? error.response.status : 500).json({ error: 'Sorry, couldn\'t get the movie.' });
    }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// Helper function to parse ISO 8601 duration
function parseDuration(duration) {
    const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
    const hours = (parseInt(match[1]) || 0);
    const minutes = (parseInt(match[2]) || 0);
    const seconds = (parseInt(match[3]) || 0);
    return hours * 60 + minutes + seconds / 60;
}